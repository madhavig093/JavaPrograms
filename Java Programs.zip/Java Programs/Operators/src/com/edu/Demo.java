package com.edu;

public class Demo {

	public static void main(String[] args) {
		int a = 10;
		int b = 20;
		System.out.println("addition"+(a +b));
	}

}
