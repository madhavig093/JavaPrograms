package com.edu;

public class Logical {

	public static void main(String[] args) {
		int x = 40;
		int y = 45;
		if(++x<40 || ++y>45) {
			x++;
			System.out.println(x);
			System.out.println(y);
		}
		else {
			y++;
			System.out.println(x);
			System.out.println(y);
			
		}

	}

}
