package com.edu;

import org.springframework.stereotype.Component;

@Component
public class Student {
	public void display() {
		System.out.println("Hello All");
	}

}
