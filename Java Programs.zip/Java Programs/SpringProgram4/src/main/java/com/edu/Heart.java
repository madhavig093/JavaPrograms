package com.edu;

public class Heart {
	public void heartBeat() {
		System.out.println("Heart is beating human alive");
	}

}
