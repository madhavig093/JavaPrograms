package com.edu;

import org.springframework.stereotype.Component;

@Component
public class EmployeeDetails {
	public void helloEmployee() {
		System.out.println("My Employee Method");
	}

}
