package com.edu;

public class SwapNumbers {

	public static void main(String[] args) {
		int a = 50;
		int b = 40;
		System.out.println("Before swap");
		System.out.println("a: "+a);
		System.out.println("b: "+b);
		int c = a;
		a = b;
		b = c;
		System.out.println("After swap");
		System.out.println("a: "+a);
		System.out.println("b: "+b);

	}

}
