package com.edu;

public class TotalMarks {

	public static void main(String[] args) {
		int maths = 85;
		int IOT = 80;
		int NoSql = 85;
		int English = 90;
		int Hindi = 97;
		int Management = 70;
		int markspersubject = 100;
		double sum = maths+IOT+NoSql+English+Hindi+Management;
		System.out.println("Total of all subjects: "+sum);
		double percentage = (sum*100)/(6*markspersubject);
		System.out.println("Percentage: "+percentage);
	}

}
