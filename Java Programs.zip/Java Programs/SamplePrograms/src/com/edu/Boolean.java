package com.edu;

import java.util.Scanner;

public class Boolean {

	public static void main(String[] args) {
		int a ;
		int b ;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a");
		a = sc.nextInt();
		System.out.println("Enter b");
		b = sc.nextInt();
		System.out.println(a<60 || a<b);

	}

}
