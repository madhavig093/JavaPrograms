package com.edu;

import org.springframework.stereotype.Component;

@Component
public class Product {
	
	public void productDisplay() {
		System.out.println("Product Method");
	}

}
